SET IDENTITY_INSERT Aircraft ON;

INSERT INTO Aircraft (AircraftID,Registration,Manuf,Model,CanDoAeros,CanDoIMC,CanDoNight,CanDoMulti) VALUES (1,'G-29572','Cessna','C172',1,1,1,0);
INSERT INTO Aircraft (AircraftID,Registration,Manuf,Model,CanDoAeros,CanDoIMC,CanDoNight,CanDoMulti) VALUES (2,'G-10593','Cessna','C152',1,0,0,0);
INSERT INTO Aircraft (AircraftID,Registration,Manuf,Model,CanDoAeros,CanDoIMC,CanDoNight,CanDoMulti) VALUES (3,'G-48201','Cessna','C152',0,0,0,0);

SET IDENTITY_INSERT Aircraft OFF;


SET IDENTITY_INSERT AircraftDiary ON;


INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (2,1,'20011121',7,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (3,1,'20011128',7,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (5,2,'20011204',7,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (6,1,'20011211',7,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (9,3,'20011204',9,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (10,3,'20011128',9,'CONFIRMED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (11,1,'20011126',9,'CONFIRMED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (12,2,'20011125' ,9,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (13,3,'20011217',9,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (14,2,'20011212',9,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (15,2,'20011213',9,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (16,1,'20020107',9,'CONFIRMED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (19,3,'20020121',9,'RESERVED');
INSERT INTO AircraftDiary (AircraftDiaryID,AircraftID,DiaryDate,BookedMemberID,Status) VALUES (20,3,'20020128',9,'RESERVED');

SET IDENTITY_INSERT AircraftDiary OFF;


SET IDENTITY_INSERT Instructor ON;

INSERT INTO Instructor (InstructorID,Title,Forename,Surname,CanDoAeros,CanDoIMC,CanDoNight,CanDoMulti) VALUES (1,'Mr','Fred ','Bloggs',1,1,0,0);
INSERT INTO Instructor (InstructorID,Title,Forename,Surname,CanDoAeros,CanDoIMC,CanDoNight,CanDoMulti) VALUES (2,'Mr','Gordon','Bennet',1,1,1,1);
INSERT INTO Instructor (InstructorID,Title,Forename,Surname,CanDoAeros,CanDoIMC,CanDoNight,CanDoMulti) VALUES (3,'Mrs','Mary','Burns',0,1,0,1);


SET IDENTITY_INSERT Instructor OFF;

SET IDENTITY_INSERT InstructorDiary ON;

INSERT INTO InstructorDiary (InstructorDiaryID,InstructorID,DiaryDate,BookedMemberID,Status) VALUES (4,1,'20011121',7,'RESERVED');
INSERT INTO InstructorDiary (InstructorDiaryID,InstructorID,DiaryDate,BookedMemberID,Status) VALUES (5,1,'20011128',7,'RESERVED');
INSERT INTO InstructorDiary (InstructorDiaryID,InstructorID,DiaryDate,BookedMemberID,Status) VALUES (7,3,'20011204',7,'CONFIRMED');
INSERT INTO InstructorDiary (InstructorDiaryID,InstructorID,DiaryDate,BookedMemberID,Status) VALUES (8,1,'20011211',7,'RESERVED');

SET IDENTITY_INSERT InstructorDiary OFF;

SET IDENTITY_INSERT Member ON;


INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (1,'MRS','JILL','ARCHER',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (2,'MR','ALISTAIR','LLOYD',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (3,'MRS','SATYA','KHANNA',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (4,'MISS','BRENDA','TUCKER',0);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (5,'MRS','CAROLINE','PEMBERTON',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (6,'MR','EDDIE','GRUNDY',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (7,'MR','GREG','TURNER',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (8,'MR','JEAN-PAUL','AUBERT',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (9,'MR','LUCAS','MADI',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (10,'MR','OLIVER','STERLING',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (11,'MR','SCOTT','DANIELS',0);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (12,'MS','USHA','GUPTA',0);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (13,'MR','WAYNE','FOLEY',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (14,'MR','SIMON','GERRARD',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (15,'MRS','SUSAN','CARTER',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (16,'MRS','PEGGY','WOOLLEY',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (17,'MR','ROBERT','SNELL',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (18,'MRS','LYNDA','SNELL',1);
INSERT INTO Member (MemberID,Title,Forename,Surname,IsStudent) VALUES (19,'DR','TIM','HATHAWAY',0);

SET IDENTITY_INSERT Member OFF;








