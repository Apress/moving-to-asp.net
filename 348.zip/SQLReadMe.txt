Instructions for creating the HiFlyer database using SQLServer.
---------------------------------------------------------------



You need 
1 - SQLServer or MSDE
2 - schema.sql
3 - data.sql

To set up the HiFlyer database, create a database called HiFlyer . Use schema.sql to create the required tables and indexes, and then use data.sql to insert the sample data.

If you have Visual Studio.NET installed, you can create the database entirely from within Visual Studio.NET using the following steps

1 - Use the Data Connections node in the Server Explorer to create a new SQLServer Database on your chosen server, with the name of 'HiFlyer'.

2 - Create a new project by opening the 'New Project; dialog. Select 'Other Projects' as the project type, and 'Database Project' as the template. 

3 - In Solution Explorer, right click on the project name and select 'Add Existing Item'. Add both schema.sql and data.sql to the project.

4 - Right click on schema.sql and click run. Repeat the process for data.sql

Check that the tables and data have been created.

best wishes and good luck

Steve and Rob


