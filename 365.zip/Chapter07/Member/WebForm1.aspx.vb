Option Strict On
Imports System.Data.SqlClient
Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents txtID As System.Web.UI.WebControls.TextBox
    Protected WithEvents pnlMemberDetails As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtForeName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtSurName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnNewMember As System.Web.UI.WebControls.Button
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents btnDelete As System.Web.UI.WebControls.Button
    Protected WithEvents btnBookings As System.Web.UI.WebControls.Button
        Protected WithEvents btnFind As System.Web.UI.WebControls.Button
    Protected WithEvents cdGetMember As System.Data.SqlClient.SqlCommand
    Protected WithEvents chkStudent As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents cdUpdateMember As System.Data.SqlClient.SqlCommand
    Protected WithEvents lstBookings As System.Web.UI.WebControls.ListBox
    Protected WithEvents cdShowBookings As System.Data.SqlClient.SqlCommand
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents cdDeleteMember As System.Data.SqlClient.SqlCommand
    Protected WithEvents cdDeleteAircraftBookings As System.Data.SqlClient.SqlCommand
    Protected WithEvents cdDeleteInstructorBookings As System.Data.SqlClient.SqlCommand
    Protected WithEvents cdNewMember As System.Data.SqlClient.SqlCommand

    Private IDModified As Boolean = False

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        Me.cdGetMember = New System.Data.SqlClient.SqlCommand()
        Me.cdUpdateMember = New System.Data.SqlClient.SqlCommand()
        Me.cdDeleteInstructorBookings = New System.Data.SqlClient.SqlCommand()
        Me.cdDeleteAircraftBookings = New System.Data.SqlClient.SqlCommand()
        Me.cdShowBookings = New System.Data.SqlClient.SqlCommand()
        Me.cdDeleteMember = New System.Data.SqlClient.SqlCommand()
        Me.cdNewMember = New System.Data.SqlClient.SqlCommand()
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=ermine;initial catalog=HiFlyer;UID=sa;PWD=;workstation id=ERMINE;pack" & _
        "et size=4096"
        '
        'cdGetMember
        '
        Me.cdGetMember.CommandText = "SELECT Member.* FROM Member WHERE (MemberID = @MemberID)"
        Me.cdGetMember.Connection = Me.cn
        Me.cdGetMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MemberID", System.Data.SqlDbType.Int))
        '
        'cdUpdateMember
        '
        Me.cdUpdateMember.CommandText = "UPDATE Member SET Title = @Title, Forename = @ForeName, Surname = @Surname, IsStu" & _
        "dent = @IsStudent WHERE (MemberID = @MemberID) AND (Title = @OldTitle) AND (Fore" & _
        "name = @OldForeName) AND (Surname = @OldSurname) AND (IsStudent = @OldIsStudent)" & _
        ""
        Me.cdUpdateMember.Connection = Me.cn
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Title", System.Data.SqlDbType.VarChar, 12, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Title", System.Data.DataRowVersion.Current, Nothing))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ForeName", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Forename", System.Data.DataRowVersion.Current, Nothing))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Surname", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Surname", System.Data.DataRowVersion.Current, Nothing))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IsStudent", System.Data.SqlDbType.Bit, 1, "IsStudent"))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MemberID", System.Data.SqlDbType.Int, 4, "MemberID"))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OldTitle", System.Data.SqlDbType.VarChar, 12, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Title", System.Data.DataRowVersion.Current, Nothing))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OldForeName", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Forename", System.Data.DataRowVersion.Current, Nothing))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OldSurname", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Surname", System.Data.DataRowVersion.Current, Nothing))
        Me.cdUpdateMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OldIsStudent", System.Data.SqlDbType.Bit, 1, "IsStudent"))
        '
        'cdDeleteInstructorBookings
        '
        Me.cdDeleteInstructorBookings.CommandText = "DELETE FROM InstructorDiary WHERE (BookedMemberID = @MemberID)"
        Me.cdDeleteInstructorBookings.Connection = Me.cn
        Me.cdDeleteInstructorBookings.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MemberID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "BookedMemberID", System.Data.DataRowVersion.Current, Nothing))
        '
        'cdDeleteAircraftBookings
        '
        Me.cdDeleteAircraftBookings.CommandText = "DELETE FROM AircraftDiary WHERE (BookedMemberID = @MemberID)"
        Me.cdDeleteAircraftBookings.Connection = Me.cn
        Me.cdDeleteAircraftBookings.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MemberID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "BookedMemberID", System.Data.DataRowVersion.Current, Nothing))
        '
        'cdShowBookings
        '
        Me.cdShowBookings.CommandText = "SELECT AircraftDiary.AircraftID, AircraftDiary.DiaryDate, AircraftDiary.Status, A" & _
        "ircraft.Registration, Aircraft.Manuf, Aircraft.Model FROM AircraftDiary INNER JO" & _
        "IN Aircraft ON AircraftDiary.AircraftID = Aircraft.AircraftID WHERE (AircraftDia" & _
        "ry.BookedMemberID = @MemberID)"
        Me.cdShowBookings.Connection = Me.cn
        Me.cdShowBookings.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MemberID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "BookedMemberID", System.Data.DataRowVersion.Current, Nothing))
        '
        'cdDeleteMember
        '
        Me.cdDeleteMember.CommandText = "DELETE FROM Member WHERE (MemberID = @MemberID)"
        Me.cdDeleteMember.Connection = Me.cn
        Me.cdDeleteMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MemberID", System.Data.SqlDbType.Int, 4, "MemberID"))
        '
        'cdNewMember
        '
        Me.cdNewMember.CommandText = "dbo.[NewMember]"
        Me.cdNewMember.CommandType = System.Data.CommandType.StoredProcedure
        Me.cdNewMember.Connection = Me.cn
        Me.cdNewMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me.cdNewMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Title", System.Data.SqlDbType.VarChar, 12))
        Me.cdNewMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Forename", System.Data.SqlDbType.VarChar, 20))
        Me.cdNewMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Surname", System.Data.SqlDbType.VarChar, 20))
        Me.cdNewMember.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IsStudent", System.Data.SqlDbType.Bit, 1))

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If IsPostBack Then
            pnlMemberDetails.Visible = True
        Else
            pnlMemberDetails.Visible = False
        End If

    End Sub

    Private Sub Find(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click
        Dim MemberID As String = txtID.Text
        Dim dr As SqlDataReader
        Try
            cdGetMember.Parameters("@MemberID").Value = CInt(MemberID)
            cn.Open()
            dr = cdGetMember.ExecuteReader(CommandBehavior.SingleResult)
            dr.Read()

            txtTitle.Text = dr("Title").ToString
            txtForeName.Text = dr("ForeName").ToString
            txtSurName.Text = dr("Surname").ToString
            chkStudent.Checked = CType(dr("IsStudent"), Boolean)
            ViewState("Title") = txtTitle.Text
            ViewState("ForeName") = txtForeName.Text
            ViewState("SurName") = txtSurName.Text
            ViewState("IsStudent") = chkStudent.Checked

        Catch exc As Exception
            lblError.Text = "Unable to find details for Member " + MemberID
            lblError.Text = exc.Message
            lblError.Visible = True
            pnlMemberDetails.Visible = False
        Finally
            If Not dr Is Nothing Then dr.Close()
            cn.Close()
        End Try
    End Sub

    Private Sub Update(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim MemberID As String = txtID.Text
        If IDModified Then
            lblError.Text = "Unable to perform update when MemberID has been modified"
            lblError.Visible = True
            pnlMemberDetails.Visible = False
            Exit Sub
        End If
        Try
            With cdUpdateMember.Parameters
                'set the old values
                .Item("@OldTitle").Value = ViewState("Title")
                .Item("@OldForeName").Value = ViewState("ForeName")
                .Item("@OldSurName").Value = ViewState("SurName")
                .Item("@OldIsStudent").Value = ViewState("IsStudent")
                'set the current values
                .Item("@MemberID").Value = MemberID
                .Item("@Title").Value = txtTitle.Text
                .Item("@ForeName").Value = txtForeName.Text
                .Item("@SurName").Value = txtSurName.Text
                .Item("@IsStudent").Value = CInt(chkStudent.Checked)
            End With

            cn.Open()
            If cdUpdateMember.ExecuteNonQuery() = 0 Then
                lblError.Text = "Update failed because another user has modified your data"
                lblError.Visible = True
            End If

        Catch ex As Exception
            lblError.Text = "Unable to perform update for Member " + MemberID
            lblError.Visible = True
        Finally
            cn.Close()
        End Try
    End Sub

    Private Sub btnBookings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBookings.Click
        Dim MemberID As String = txtID.Text
        Dim dr As SqlDataReader
        Dim Booking As String
        Const AIRCRAFTID_COL As Integer = 0
        Const DIARYDATE_COL As Integer = 1
        Const STATUS_COL As Integer = 2
        Const REGISTRATION_COL As Integer = 3
        Const MANUF_COL As Integer = 4
        Const MODEL_COL As Integer = 5
        Try
            cdShowBookings.Parameters("@MemberID").Value = CInt(MemberID)
            cn.Open()
            dr = cdShowBookings.ExecuteReader()
            lstBookings.Items.Clear()
            While dr.Read()
                Booking = dr.GetDateTime(DIARYDATE_COL).ToShortDateString + " "
                Booking += dr.GetString(STATUS_COL) + " "
                Booking += dr.GetInt32(AIRCRAFTID_COL).ToString() + " "
                Booking += dr.GetString(REGISTRATION_COL) + " "
                Booking += dr.GetString(MANUF_COL) + " "
                Booking += dr.GetString(MODEL_COL) + " "
                lstBookings.Items.Add(Booking)
            End While
            lstBookings.Visible = True
        Catch ex As Exception
            lblError.Text = "Unable to find details for Member " + MemberID
            lblError.Visible = True
            pnlMemberDetails.Visible = False
        Finally
            If Not dr Is Nothing Then dr.Close()
            cn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim MemberID As String = txtID.Text
        Dim dr As SqlDataReader
        Dim cn As New SqlConnection()
        Dim cd As New SqlCommand()
        Try
            cn.ConnectionString = "Data Source=localhost;" + _
                 "Integrated Security=SSPI;Initial Catalog=HiFlyer;"
            cd.Connection = cn
            cd.CommandText = "select Title, ForeName, Surname,IsStudent " + _
                      "from Member where MemberID = " + MemberID + ""
            cn.Open()
            dr = cd.ExecuteReader(CommandBehavior.SingleRow)
            dr.Read()
            txtTitle.Text = dr("Title").ToString
            txtForeName.Text = dr("ForeName").ToString
            txtSurName.Text = dr("Surname").ToString
            chkStudent.Checked = CType(dr("IsStudent"), Boolean)
        Catch
            lblError.Text = "Unable to find details for Member " + MemberID
            lblError.Visible = True
            pnlMemberDetails.Visible = False
        Finally
            If Not dr Is Nothing Then dr.Close()
            cn.Close()
        End Try
    End Sub


    Private Sub txtID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtID.TextChanged
        'IDModified = True
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim MemberID As String = txtID.Text
        Dim tx As SqlTransaction
        Try

            cdDeleteMember.Parameters("@MemberID").Value = CInt(MemberID)
            cdDeleteAircraftBookings.Parameters("@MemberID").Value = CInt(MemberID)
            cdDeleteInstructorBookings.Parameters("@MemberID").Value = CInt(MemberID)
            cn.Open()
            tx = cn.BeginTransaction

            cdDeleteMember.Transaction = tx
            cdDeleteAircraftBookings.Transaction = tx
            cdDeleteInstructorBookings.Transaction = tx

            cdDeleteMember.ExecuteNonQuery()
            cdDeleteAircraftBookings.ExecuteNonQuery()
            cdDeleteInstructorBookings.ExecuteNonQuery()
            tx.Commit()
        Catch
            If Not tx Is Nothing Then tx.Rollback()
            lblError.Text = "Unable to delete Member " + MemberID
            lblError.Visible = True
            pnlMemberDetails.Visible = False
        Finally
            cn.Close()
        End Try
    End Sub

    Private Sub btnNewMember_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewMember.Click
        Try
            With cdNewMember.Parameters
                .Item("@Title").Value = txtTitle.Text
                .Item("@ForeName").Value = txtForeName.Text
                .Item("@SurName").Value = txtSurName.Text
                .Item("@IsStudent").Value = CInt(chkStudent.Checked)

                cn.Open()
                cdNewMember.ExecuteNonQuery()
                txtID.Text = .Item("@RETURN_VALUE").Value.ToString
            End With
        Catch
            lblError.Text = "Unable to create new Member"
            lblError.Visible = True
        Finally
            cn.Close()
        End Try
    End Sub

 
  
End Class
