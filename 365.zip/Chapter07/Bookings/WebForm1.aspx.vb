Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents btnGetBookings As System.Web.UI.WebControls.Button
    Protected WithEvents rdlSort As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents chlFilter As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents lstBookings As System.Web.UI.WebControls.ListBox
    Protected WithEvents txtID As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents lblRegistration As System.Web.UI.WebControls.Label
    Protected WithEvents lblManufacturer As System.Web.UI.WebControls.Label
    Protected WithEvents chkIMC As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkMulti As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lblModel As System.Web.UI.WebControls.Label
    Protected WithEvents chkAeros As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkNight As System.Web.UI.WebControls.CheckBox
    Protected WithEvents btnConfirm As System.Web.UI.WebControls.Button
    Protected WithEvents btnDelete As System.Web.UI.WebControls.Button
    Protected WithEvents da As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents daAircraft As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents btnApply As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.da = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.daAircraft = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand()
        '
        'da
        '
        Me.da.DeleteCommand = Me.SqlDeleteCommand1
        Me.da.InsertCommand = Me.SqlInsertCommand1
        Me.da.SelectCommand = Me.SqlSelectCommand1
        Me.da.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "AircraftDiary", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("AircraftDiaryID", "AircraftDiaryID"), New System.Data.Common.DataColumnMapping("AircraftID", "AircraftID"), New System.Data.Common.DataColumnMapping("DiaryDate", "DiaryDate"), New System.Data.Common.DataColumnMapping("Status", "Status")})})
        Me.da.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM AircraftDiary WHERE (AircraftDiaryID = @Original_AircraftDiaryID)"
        Me.SqlDeleteCommand1.Connection = Me.cn
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_AircraftDiaryID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "AircraftDiaryID", System.Data.DataRowVersion.Original, Nothing))
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=ermine;initial catalog=HiFlyer;UID=sa;PWD=;workstation id=ERMINE;pack" & _
        "et size=4096"
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO AircraftDiary(AircraftID, DiaryDate, Status) VALUES (@AircraftID, @Di" & _
        "aryDate, @Status)"
        Me.SqlInsertCommand1.Connection = Me.cn
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AircraftID", System.Data.SqlDbType.Int, 4, "AircraftID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DiaryDate", System.Data.SqlDbType.DateTime, 8, "DiaryDate"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 11, "Status"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT AircraftDiaryID, AircraftID, DiaryDate, Status FROM AircraftDiary WHERE (B" & _
        "ookedMemberID = @Member)"
        Me.SqlSelectCommand1.Connection = Me.cn
        Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Member", System.Data.SqlDbType.Int, 4, "BookedMemberID"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE AircraftDiary SET AircraftID = @AircraftID, DiaryDate = @DiaryDate, Status" & _
        " = @Status WHERE (AircraftDiaryID = @Original_AircraftDiaryID)"
        Me.SqlUpdateCommand1.Connection = Me.cn
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AircraftID", System.Data.SqlDbType.Int, 4, "AircraftID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DiaryDate", System.Data.SqlDbType.DateTime, 8, "DiaryDate"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 11, "Status"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_AircraftDiaryID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "AircraftDiaryID", System.Data.DataRowVersion.Original, Nothing))
        '
        'daAircraft
        '
        Me.daAircraft.SelectCommand = Me.SqlSelectCommand2
        Me.daAircraft.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Aircraft", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("AircraftID", "AircraftID"), New System.Data.Common.DataColumnMapping("Registration", "Registration"), New System.Data.Common.DataColumnMapping("Manuf", "Manuf"), New System.Data.Common.DataColumnMapping("Model", "Model"), New System.Data.Common.DataColumnMapping("CanDoAeros", "CanDoAeros"), New System.Data.Common.DataColumnMapping("CanDoIMC", "CanDoIMC"), New System.Data.Common.DataColumnMapping("CanDoNight", "CanDoNight"), New System.Data.Common.DataColumnMapping("CanDoMulti", "CanDoMulti")})})
        '
        'SqlSelectCommand2
        '
        Me.SqlSelectCommand2.CommandText = "SELECT AircraftID, Registration, Manuf, Model, CanDoAeros, CanDoIMC, CanDoNight, " & _
        "CanDoMulti FROM Aircraft"
        Me.SqlSelectCommand2.Connection = Me.cn

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub btnGetBookings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetBookings.Click



        Dim dr As DataRow
        Dim Booking As String
        Dim MemberID As String = txtID.Text
        Try
            Dim ds As New DataSet()
            da.SelectCommand.Parameters("@Member").Value = MemberID
            da.Fill(ds, "Bookings")
            daAircraft.Fill(ds, "Aircraft")
            Session("Data") = ds
            Dim rl As New DataRelation("Rel1", _
                             ds.Tables("Aircraft").Columns("AircraftID"), _
                             ds.Tables("Bookings").Columns("AircraftID"))
            ds.Relations.Add(rl)

            Dim dt As DataTable = ds.Tables("Bookings")
            lstBookings.Items.Clear()
            For Each dr In dt.Rows
                Booking = dr("AircraftID").ToString + " "
                Booking += dr("DiaryDate").ToString + " "
                Booking += dr("Status").ToString
                lstBookings.Items.Add(Booking)
            Next
        Catch
            lblError.Text = "Unable to find details for Member " + MemberID
            lblError.Visible = True
        End Try


    End Sub

    Private Sub btnApply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnApply.Click
        Dim dt As DataTable
        Dim drs() As DataRow
        Dim Filter, Sort As String
        Try
            getCriteria(Filter, Sort)
            dt = CType(Session("Data"), DataSet).Tables("Bookings")
            drs = dt.Select(Filter, Sort)

            Dim dr As DataRow
            Dim i As Integer
            Dim Booking As String
            lstBookings.Items.Clear()
            For i = 0 To drs.Length - 1
                dr = drs(i)

                Booking = dr("AircraftID").ToString + " "
                Booking += dr("DiaryDate").ToString + " "
                Booking += dr("Status").ToString
                lstBookings.Items.Add(Booking)
            Next
        Catch
            lblError.Text = "Unable to display data "
            lblError.Visible = True
        End Try
    End Sub


    Private Sub lstBookings_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstBookings.SelectedIndexChanged
        Dim drChild As DataRow

        Dim ds As DataSet = CType(Session("Data"), DataSet)
        Dim Filter, Sort As String
        Dim drs() As DataRow
        Dim dt As DataTable
        getCriteria(Filter, Sort)
        dt = CType(Session("Data"), DataSet).Tables("Bookings")
        drs = dt.Select(Filter, Sort)
        drChild = drs(lstBookings.SelectedIndex)
        Dim drParent As DataRow
        drParent = drChild.GetParentRow("Rel1")
        lblRegistration.Text = drParent("Registration").ToString
        lblManufacturer.Text = drParent("Manuf").ToString
        lblModel.Text = drParent("Model").ToString
        chkAeros.Checked = CBool(drParent("CanDoAeros"))
        chkIMC.Checked = CBool(drParent("CanDoIMC"))
        chkNight.Checked = CBool(drParent("CanDoNight"))
        chkMulti.Checked = CBool(drParent("CanDoMulti"))
    End Sub

    Private Sub getCriteria(ByRef Filter As String, ByRef Sort As String)

        If chlFilter.Items(0).Selected Xor chlFilter.Items(1).Selected Then
            Filter = "Status = '" + chlFilter.SelectedItem.Value + "'"
        End If
        If Not (rdlSort.SelectedItem Is Nothing) Then
            Sort = rdlSort.SelectedItem.Value
        End If

    End Sub

    Private Sub btnConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirm.Click
        If lstBookings.SelectionMode = ListSelectionMode.Single Then
            Dim ds As DataSet = CType(Session("Data"), DataSet)
            Dim dt As DataTable = ds.Tables("Bookings")
            'assume no filtering or sorting
            Dim Row As Integer = lstBookings.SelectedIndex
            Dim dr As DataRow = dt.Rows(Row)
            'change the data here
            dr("Status") = "CONFIRMED"
            'call the Apply button code to re-build the list
            btnApply_Click(Nothing, Nothing)

            'create an array containing one DataRow
            Dim drs() As DataRow = {dr}

            da.Update(drs)
        Else
            Dim ds As DataSet = CType(Session("Data"), DataSet)
            Dim dt As DataTable = ds.Tables("Bookings")
            Dim dr As DataRow
            Dim i As Integer
            'assume no filtering or sorting
            For i = 0 To lstBookings.Items.Count - 1
                If lstBookings.Items(i).Selected Then
                    dr = dt.Rows(i)
                    'change the data here
                    dr("Status") = "CONFIRMED"
                End If
            Next
            'call the Apply button code to re-build the list
            Dim cn As SqlClient.SqlConnection
            Dim tx As SqlClient.SqlTransaction
            Try
                cn = da.UpdateCommand.Connection
                cn.Open()
                tx = cn.BeginTransaction
                da.UpdateCommand.Transaction = tx
                da.DeleteCommand.Transaction = tx
                da.InsertCommand.Transaction = tx
                da.Update(dt)
                tx.Commit()
                dt.AcceptChanges()
            Catch
                tx.Rollback()
                lblError.Text = "Update(s) failed because another user has been updating this data"
                lblError.Visible = True
                dt.RejectChanges()
            Finally
                cn.Close()
                btnGetBookings_Click(Nothing, Nothing)
            End Try
        End If
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim ds As DataSet = CType(Session("Data"), DataSet)
        Dim dt As DataTable = ds.Tables("Bookings")
        'assume no filtering or sorting
        Dim Row As Integer = lstBookings.SelectedIndex
        Dim dr As DataRow = dt.Rows(Row)
        'delete the row here
        dr.Delete()
        'call the Apply button code to re-build the list
        btnApply_Click(Nothing, Nothing)
    End Sub


End Class
