Imports System.ComponentModel
Imports System.Web.UI

<DefaultProperty("SelectedDate"), ValidationProperty("SelectedDate"), ToolboxData("<{0}:HFCalendar runat=server></{0}:HFCalendar>")> _
    Public Class HFCalendar
    Inherits System.Web.UI.WebControls.WebControl
    Implements IPostBackDataHandler

    Public Event DateChanged As EventHandler

    <Category("Appearance")> _
        Property SelectedDate() As Date
        Get
            Try
                Return Date.Parse(Viewstate("Date").ToString)
            Catch
                Return Date.Today
            End Try
        End Get

        Set(ByVal Value As Date)
            ViewState("Date") = Value
        End Set
    End Property

    Protected Overrides Sub RenderContents(ByVal output As System.Web.UI.HtmlTextWriter)
        Dim strFormName As String = Me.Parent.UniqueID
        Dim strControlName As String = Me.UniqueID
        Dim strOutput As String

        If Page.Request.Browser.JavaScript Then
            strOutput = "<INPUT type=text disabled align=top id=" & strControlName & "_Date name=" & strControlName & "_Date style=""WIDTH: 83px; HEIGHT: 22px"" value=""" & Format(SelectedDate, "dd/MMM/yyyy") & """>"
            strOutput += "<INPUT type=hidden align=top id=" & strControlName & " name=" & strControlName & " value=""" & SelectedDate.ToShortDateString & """>"
            strOutput += "<INPUT type=button id=" & strControlName & "_Button onclick=""javascript:CreateCalendar(" & strFormName & "." & strControlName & "_Date, " & strFormName & "." & strControlName & ");"" name=cmdDisplayCal style=""WIDTH: 22px; HEIGHT: 22px"" value=""..."">"
        Else
            strOutput += "<INPUT type=text align=top id=" & strControlName & " name=" & strControlName & " style=""VISIBILITY: visible; WIDTH: 83px; HEIGHT: 22px"" value=""" & SelectedDate.ToShortDateString & """>"
        End If

        output.Write(strOutput)
    End Sub

    Private Sub HFCalendar_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If SelectedDate = #12:00:00 AM# Then
            SelectedDate = Date.Today()
        End If
    End Sub

    Public Function LoadPostData(ByVal postDataKey As String, ByVal postCollection As System.Collections.Specialized.NameValueCollection) As Boolean Implements System.Web.UI.IPostBackDataHandler.LoadPostData
        Dim strPostedDate As String = postCollection(postDataKey)

        If Not SelectedDate.Equals(Date.Parse(strPostedDate)) Then
            SelectedDate = Date.Parse(strPostedDate)
            Return True
        Else
            Return False
        End If
        Page.Trace.Write("Control", "LoadPostData")
    End Function

    Public Sub RaisePostDataChangedEvent() Implements System.Web.UI.IPostBackDataHandler.RaisePostDataChangedEvent
        Page.Trace.Write("Control", "RaisePostDataChangedEvent")
        RaiseEvent DateChanged(Me, EventArgs.Empty)
    End Sub

    Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
        MyBase.OnInit(e)
        Page.Trace.Write("Control", "OnInit")
    End Sub

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        MyBase.OnLoad(e)
        Page.Trace.Write("Control", "OnLoad")
    End Sub

    Protected Overrides Sub LoadViewState(ByVal savedState As Object)
        MyBase.LoadViewState(savedState)
        Page.Trace.Write("Control", "LoadViewState")
    End Sub

    Private Sub HFCalendar_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        If Page.Request.Browser.JavaScript AndAlso Not Page.IsClientScriptBlockRegistered("CalendarJS") Then
            Page.RegisterClientScriptBlock("CalendarJS", "<script language=""JavaScript"" src=""Calendar.js""></script>")
        End If
    End Sub
End Class
