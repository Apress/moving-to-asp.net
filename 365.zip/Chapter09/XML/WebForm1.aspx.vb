Option Strict On
Imports System.Xml

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents ListBox1 As System.Web.UI.WebControls.ListBox
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Button3 As System.Web.UI.WebControls.Button
    Protected WithEvents Button4 As System.Web.UI.WebControls.Button
    Protected WithEvents DIV1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents Button5 As System.Web.UI.WebControls.Button
    Protected WithEvents Button6 As System.Web.UI.WebControls.Button
    Protected WithEvents Button7 As System.Web.UI.WebControls.Button
    Protected WithEvents Button8 As System.Web.UI.WebControls.Button
    Protected WithEvents Button9 As System.Web.UI.WebControls.Button
    Protected WithEvents cd As System.Data.SqlClient.SqlCommand

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        Me.cd = New System.Data.SqlClient.SqlCommand()
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=ERMINE;initial catalog=HiFlyer;UID=sa;PWD=;workstation id=ERMINE;pack" & _
        "et size=4096"
        '
        'cd
        '
        Me.cd.CommandText = "SELECT Aircraft.* FROM Aircraft FOR XML AUTO, ELEMENTS"
        Me.cd.Connection = Me.cn

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim xr As XmlReader
        Dim NodeString As String
        cd.Connection.Open()
        xr = cd.ExecuteXmlReader

        While (xr.Read)
            NodeString = New String("-"c, xr.Depth * 2)
            NodeString += xr.NodeType.ToString + ":" + xr.Name + ":" + xr.Value
            ListBox1.Items.Add(NodeString)
        End While

        xr.Close()
        cd.Connection.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim xr As XmlTextReader
        Dim NodeString As String
        xr = New XmlTextReader(Server.MapPath("data.xml"))
        xr.WhitespaceHandling = WhitespaceHandling.None

        While (xr.Read)
            If Not (xr.NodeType = XmlNodeType.XmlDeclaration Or xr.Name = "Fleet") Then
                NodeString = New String("-"c, xr.Depth * 2)
                NodeString += xr.NodeType.ToString + ":" + xr.Name + ":" + xr.Value
                ListBox1.Items.Add(NodeString)
            End If
        End While

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim xr As XmlTextReader
        Dim Description As String
        xr = New XmlTextReader(Server.MapPath("data.xml"))
        xr.WhitespaceHandling = WhitespaceHandling.None

        While (xr.Read)
            If xr.NodeType = XmlNodeType.Element And xr.Name = "Aircraft" Then
                Description = ""
            End If
            Select Case xr.Name
                Case "Registration", "Model", "CanDoAeros"
                    If xr.NodeType = XmlNodeType.Element Then
                        xr.Read()
                        Description += xr.Value.ToString + " "

                    End If
            End Select
            If xr.NodeType = XmlNodeType.EndElement And xr.Name = "Aircraft" Then
                ListBox1.Items.Add(Description)
            End If

        End While

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim doc As New XmlDocument()
        Dim tfm As New Xsl.XslTransform()
        Dim output As New System.IO.StringWriter()
        doc.Load(Server.MapPath("data.xml"))
        tfm.Load(Server.MapPath("data.xslt"))
        tfm.Transform(doc, Nothing, output)
        DIV1.InnerHtml = output.ToString


    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim doc As New XmlDocument()

        doc.Load(Server.MapPath("data.xml"))

        Dim docNode, aircraftNode, dataNode As XmlNode
        Dim i, j As Integer
        Dim Description As String
        docNode = doc.DocumentElement
        For i = 0 To docNode.ChildNodes.Count - 1
            aircraftNode = docNode.ChildNodes(i)
            Description = ""
            For j = 1 To aircraftNode.ChildNodes.Count
                dataNode = aircraftNode.ChildNodes(j - 1)
                Select Case dataNode.Name
                    Case "Registration", "Model", "CanDoAeros"

                        Description += dataNode.InnerText.ToString + " "
                End Select
            Next
            ListBox1.Items.Add(Description)
        Next
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim doc As New XmlDocument()
        Dim aircraftNode As XmlNode
        Dim Description As String
        doc.Load(Server.MapPath("data.xml"))
        For Each aircraftNode In doc.SelectNodes("/Fleet/Aircraft[CanDoAeros='true']")
            Description = aircraftNode("Registration").InnerXml + " "
            Description += aircraftNode("Model").InnerXml + " "
            Description += aircraftNode("CanDoAeros").InnerXml + " "
            ListBox1.Items.Add(Description)
        Next
       
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim doc As New XmlDocument()
        Dim aircraftNode As XmlNode
        Dim Description As String

        doc.Load(Server.MapPath("data.xml"))
        For Each aircraftNode In doc.SelectNodes("/Fleet/Aircraft")
            Description = aircraftNode.SelectSingleNode("Registration").InnerXml + " "
            Description += aircraftNode.SelectSingleNode("Model").InnerXml + " "
            Description += aircraftNode.SelectSingleNode("CanDoAeros").InnerXml + " "
            ListBox1.Items.Add(Description)
        Next
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim xr As XmlTextReader
        Dim Description As String
        xr = New XmlTextReader(Server.MapPath("data.xml"))

        xr.WhitespaceHandling = WhitespaceHandling.None

        While (xr.Read)
            If xr.NodeType = XmlNodeType.Element And xr.Name = "Aircraft" Then
                Description = ""
            End If
            Select Case xr.Name
                Case "Registration", "Model", "CanDoAeros"
                    If xr.NodeType = XmlNodeType.Element Then
                        xr.Read()
                        Description += xr.Value.ToString + " "

                    End If
            End Select
            If xr.NodeType = XmlNodeType.EndElement And xr.Name = "Aircraft" Then
                ListBox1.Items.Add(Description)
            End If

        End While
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        ListBox1.Items.Clear()
    End Sub
End Class
