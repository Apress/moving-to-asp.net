Public Class CheckAvailability
    Inherits System.Web.UI.Page
    Protected WithEvents lstAircraft As System.Web.UI.WebControls.ListBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents lstInstructors As System.Web.UI.WebControls.ListBox
    Protected WithEvents txtDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents RequiredFieldValidator3 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents CompareValidator1 As System.Web.UI.WebControls.CompareValidator
    Protected WithEvents RequiredFieldValidator2 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents cmdCheck As System.Web.UI.WebControls.Button
    Protected WithEvents ValidationSummary1 As System.Web.UI.WebControls.ValidationSummary
    Protected WithEvents cnHiflyer As System.Data.SqlClient.SqlConnection
    Protected WithEvents cdAircraft As System.Data.SqlClient.SqlCommand
    Protected WithEvents cdInstructor As System.Data.SqlClient.SqlCommand
    Protected WithEvents cmdCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cnHiflyer = New System.Data.SqlClient.SqlConnection()
        Me.cdAircraft = New System.Data.SqlClient.SqlCommand()
        Me.cdInstructor = New System.Data.SqlClient.SqlCommand()
        '
        'cnHiflyer
        '
        Me.cnHiflyer.ConnectionString = "data source=.;initial catalog=HiFlyer;User ID=sa;Password=;"
        '
        'cdAircraft
        '
        Me.cdAircraft.CommandText = "SELECT AircraftID, Registration FROM Aircraft"
        Me.cdAircraft.Connection = Me.cnHiflyer
        '
        'cdInstructor
        '
        Me.cdInstructor.CommandText = "SELECT InstructorID, Surname + ', ' + Forename AS Fullname FROM Instructor"
        Me.cdInstructor.Connection = Me.cnHiflyer

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Page.IsPostBack = False Then
            Dim DR As SqlClient.SqlDataReader

            cnHiflyer.Open()
            DR = cdAircraft.ExecuteReader
            With lstAircraft
                .DataSource = DR
                .DataTextField = "Registration"
                .DataValueField = "AircraftID"
                .DataBind()
            End With
            DR.Close()

            DR = cdInstructor.ExecuteReader
            With lstInstructors
                .DataSource = DR
                .DataTextField = "Fullname"
                .DataValueField = "InstructorID"
                .DataBind()
            End With
            DR.Close()

            cnHiflyer.Close()
        End If
    End Sub

    Private Sub cmdCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCheck.Click
        If Page.IsValid Then
            'Perform the check on availability

        Else
            Dim ctlValidator As BaseValidator
            Dim ctlValidatee As WebControl

            For Each ctlValidator In Page.Validators
                If ctlValidator.IsValid = False Then
                    'Identify the control to validate and set its foreground to Red
                    ctlValidatee = CType(Me.FindControl(ctlValidator.ControlToValidate), WebControl)
                    ctlValidatee.ForeColor = System.Drawing.Color.Red
                End If
            Next
        End If
    End Sub
End Class
