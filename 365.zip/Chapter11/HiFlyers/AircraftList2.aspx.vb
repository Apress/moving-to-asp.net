Imports System.Data.OleDb

Public Class AircraftList2
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim CN As New OleDbConnection("Provider=SQLOLEDB.1;Data Source=(local);Initial Catalog=HiFlyer;User ID=sa;")
        CN.Open()
        Dim CM As New OleDbCommand("SELECT AircraftID, Registration, Manuf, Model FROM Aircraft", CN)
        Dim DR As OleDbDataReader

        DR = CM.ExecuteReader()

        DataGrid1.DataSource = DR
        DataGrid1.DataBind()

        DR.Close()
        CN.Close()
    End Sub
End Class
