Public Class ServerChange
    Inherits System.Web.UI.Page
    Protected WithEvents Text1 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents DIV1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents Text2 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents Text3 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents Submit1 As System.Web.UI.HtmlControls.HtmlInputButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DIV1.InnerHtml = ""
    End Sub

    Private Sub TextBoxChange(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Text1.ServerChange, Text2.ServerChange, Text3.ServerChange
        DIV1.InnerHtml += CType(sender, HtmlInputText).ID + " changed<br>"
    End Sub

    Private Sub ButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Submit1.ServerClick
        DIV1.InnerHtml += CType(sender, HtmlInputButton).ID + " clicked<br>"
    End Sub

End Class
