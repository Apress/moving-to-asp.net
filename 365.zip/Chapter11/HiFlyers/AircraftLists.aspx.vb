Imports System.Web.Caching

Public Class AircraftLists
    Inherits System.Web.UI.Page
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents daAircraft As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents cdAllAircraft As System.Data.SqlClient.SqlCommand
    Protected WithEvents Repeater2 As System.Web.UI.WebControls.Repeater
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents Repeater1 As System.Web.UI.WebControls.Repeater
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button

    Protected dr As SqlClient.SqlDataReader

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.daAircraft = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        Me.cdAllAircraft = New System.Data.SqlClient.SqlCommand()
        '
        'daAircraft
        '
        Me.daAircraft.SelectCommand = Me.SqlSelectCommand1
        Me.daAircraft.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Aircraft", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Registration", "Registration"), New System.Data.Common.DataColumnMapping("Details", "Details"), New System.Data.Common.DataColumnMapping("AircraftID", "AircraftID")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT Registration, Manuf + ' ' + Model AS Details, AircraftID FROM Aircraft ORD" & _
        "ER BY Manuf + ' ' + Model, Registration"
        Me.SqlSelectCommand1.Connection = Me.cn
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=.;initial catalog=HiFlyer;password="""";persist security info=True;user" & _
        " id=sa;workstation id=DAYTONA-NET;packet size=4096"
        '
        'cdAllAircraft
        '
        Me.cdAllAircraft.CommandText = "SELECT Registration, Manuf + ' ' + Model AS Details FROM Aircraft ORDER BY Manuf " & _
        "+ ' ' + Model, Registration"
        Me.cdAllAircraft.Connection = Me.cn

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Me.IsPostBack = False Then
            Dim strCon As String = "Data Source=(local);Initial Catalog=HiFlyer;Integrated Security=SSPI"
            Dim strSQL As String = "SELECT Registration, Manuf + ' ' + Model AS Details, AircraftID FROM Aircraft ORDER BY Manuf + ' ' + Model, Registration"

            Dim cn As New SqlClient.SqlConnection(strCon)
            Dim cd As New SqlClient.SqlCommand(strSQL, cn)

            cn.Open()

            dr = cd.ExecuteReader
            Repeater1.DataSource = dr
            Repeater1.DataBind()
            dr.Close()

            dr = cd.ExecuteReader
            Repeater2.DataSource = dr
            Repeater2.DataBind()
            dr.Close()

            cn.Close()
        End If
    End Sub

    Public Function GetAircraftList() As DataSet
        If IsNothing(Cache("AircraftListData")) Then
            Dim strCon As String = "Data Source=(local);" & _
                    "Initial Catalog=HiFlyer;Integrated Security=SSPI"
            Dim strSQL As String = "SELECT Registration, Manuf + ' ' + Model " & _
                    "AS Details, AircraftID FROM Aircraft ORDER BY " & _
                    "Manuf + ' ' + Model, Registration"

            Dim da As New SqlClient.SqlDataAdapter(strSQL, strCon)
            Dim dsAircraft As New DataSet()

            da.Fill(dsAircraft, "List")
            Cache("AircraftListData") = dsAircraft
        End If

        Return CType(Cache("AircraftListData"), DataSet)
    End Function

    Public Function GetExchangeRates() As DataSet
        If IsNothing(Cache("ExchangeRateData")) Then
            Dim dsRates As New DataSet()
            Dim dpnFile As New Caching.CacheDependency(Server.MapPath("ExchRates.xml"))

            ' Fill dataset from the Exchange Rates file
            dsRates.ReadXml(Server.MapPath("ExchRates.xml"))

            ' Insert into the cache
            Cache.Insert("ExchangeRateData", dsRates, dpnFile)
        End If

        Return CType(Cache("ExchangeRateData"), DataSet)
    End Function

    Public Function GetPriceList() As DataSet
        If IsNothing(Cache("PriceListData")) Then
            Dim strCon As String = "...."
            Dim strSQL As String = "...."
            Dim da As New SqlClient.SqlDataAdapter(strSQL, strCon)
            Dim dsPrices As New DataSet()

            'Generate the key dependency
            Dim astrKeys() As String = {"ExchangeRateData"}
            Dim dpnKey As New Caching.CacheDependency(Nothing, astrKeys)

            'Fill the DataSet
            da.Fill(dsPrices, "List")
            Cache("PriceListData") = dsPrices

            ' Insert into the cache
            Cache.Insert("PriceListData", dsPrices, dpnKey)
        End If

        Return CType(Cache("PriceListData"), DataSet)
    End Function

    Public Function CacheWithCallBack() As DataSet
        If IsNothing(Cache("CallBackData")) Then
            Dim dsPrices As New DataSet()

            'Generate the key dependency
            '            Dim astrKeys() As String = {"ExchangeRateData"}
            '           Dim dpnKey As New Caching.CacheDependency(Nothing, astrKeys)

            ' Insert into the cache
            Cache.Insert("CallBackData", dsPrices, Nothing, Cache.NoAbsoluteExpiration, TimeSpan.FromSeconds(15), CacheItemPriority.Default, AddressOf RemovedCallback)
        End If

        Return CType(Cache("CallBackData"), DataSet)
    End Function


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CacheWithCallBack()
    End Sub

    Public Shared Sub RemovedCallback(ByVal key As String, ByVal value As Object, ByVal reason As CacheItemRemovedReason)
        Stop
    End Sub
End Class
