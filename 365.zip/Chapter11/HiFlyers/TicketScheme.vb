Public Structure Ticket
    Public HasLoggedIn As Boolean
    Public HasSelectedAircraft As Boolean
    Public HasSelectedInstructor As Boolean
    Public HasSelectedDate As Boolean
End Structure
