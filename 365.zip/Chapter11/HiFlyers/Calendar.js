function CreateCalendar()
{
	var datTemp = new Date();
	ctlShowField = arguments[0];
	ctlCalcField = arguments[1];
    ctlParent = ctlShowField.offsetParent;
	
	ctlFrame = document.getElementById("spCal");
	if (ctlFrame == undefined)
	{
		ctlFrame = document.createElement("<iframe id='spCal' STYLE='display:none; border:ridge;position:absolute;width:225;height:150;z-index=999' MARGINHEIGHT='0' MARGINWIDTH='0' NORESIZE FRAMEBORDER='0' width:156 SCROLLING='NO'></iframe>"); 
		document.body.insertBefore(ctlFrame);
	}
	else
	{
		ctlFrame = document.all.spCal;
	}
	
    ctlFrame.style.position = "relative";
    ctlFrame.style.left = ctlParent.offsetLeft - 11;
	ctlFrame.style.top = ctlParent.offsetTop + ctlParent.offsetHeight - 15;	

    if (ctlCalcField.value == "") 
		datTemp = new Date();
	else
		datTemp = new Date(ctlCalcField.value);

  	DrawCalendar(datTemp.getFullYear(), datTemp.getMonth(), datTemp.getDate());
	ctlFrame.style.display = "block";
}


function DrawCalendar (intYear, intMonth, intDay)
{
	var strHTML = new String();
	
 	//setup styles to define the look of the calendar
	strHTML += '<style>';
	strHTML += '.calHeading {background-color : Silver; border-top-style: outset; font: 8px Verdana;}'
	strHTML += '.calRegularDay {background-color : #FFEFD5;}';
	strHTML += 'A.calRegularDay.HOVER {background-color : #E6E6FA;}';
	strHTML += '.calReg, TD.calReg:ACTIVE, TD.calReg:FOCUS, TD.calReg:HOVER, TD.calReg:VISITED {';
	strHTML += 'background-color : #ffd8a8; cursor: hand; display : block;}';
	strHTML += 'TD.calReg:VISITED { background-color : Blue;} </style>';

	//Generate the calendar
    strHTML += DrawCalendarMonth(intYear, intMonth, intDay);

	//Write to the document
	self.spCal.document.open();
	self.spCal.document.write(strHTML);
    self.spCal.document.close();
}


function DrawCalendarMonth(intYear, intMonth, intDay)
{
	var strCal = new String();
	var datCurrent = new Date(intYear, intMonth, intDay);
	var intDaysInMonth = GetDaysInMonth(intMonth, intYear);
	var datFirstDayOfMonth = new Date(intYear, intMonth, 1);
	var strPrevYear = (datCurrent.getFullYear() - 1) + ', ' + (datCurrent.getMonth()) + ', 1';
	var strNextYear = (datCurrent.getFullYear() + 1) + ', ' + (datCurrent.getMonth()) + ', 1';

	var datTemp=new Date(intYear, intMonth - 1, intDay);
	var strPrevMonth = (datTemp.getFullYear()) + ', ' + (datTemp.getMonth()) + ', 1';

	datTemp=new Date(intYear, intMonth + 1, intDay);
	var strNextMonth = (datTemp.getFullYear()) + ', ' + (datTemp.getMonth()) + ', 1';

	astrWeekDaysFull  = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
	astrWeekDaysAbbrev = new Array('Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa');
    
	strCal = '<table width="100%" bordercolor="white" border=1 style="border-collapse:collapse">' + '<tr class="heading" bgcolor="beige">';
	strCal += '<td style="cursor:hand;" onmouseover="this.style.backgroundColor=\'white\';" onmouseout="this.style.backgroundColor=\'\';" onclick="parent.DrawCalendar(' + strPrevYear + ');" align=center><font face=verdana, arial size=2>&lt;&lt;</font></td>';
	strCal += '<td style="cursor:hand;" onmouseover="this.style.backgroundColor=\'white\';" onmouseout="this.style.backgroundColor=\'\';" onclick="parent.DrawCalendar(' + strPrevMonth + ');" align=center><font face="verdana, arial" size=2>&lt;</font></td>';
	strCal += '<td colspan=3 align=center><font face="verdana, arial" size=1>' + GetMonthName(intMonth, false) + ' ' + intYear + '</font></td>';
	strCal += '<td style="cursor:hand;" onmouseover="this.style.backgroundColor=\'white\';" onmouseout="this.style.backgroundColor=\'\';" onclick="parent.DrawCalendar(' + strNextMonth + ');" align=center><font face="verdana, arial" size=2>&gt;</font></td>';
	strCal += '<td style="cursor:hand;" onmouseover="this.style.backgroundColor=\'white\';" onmouseout="this.style.backgroundColor=\'\';" onclick="parent.DrawCalendar(' + strNextYear + ');" align=center><font face="verdana, arial" size=2>&gt;&gt;</font></td>';
	strCal += '</tr>';

	strWeekDays = '<tr bgcolor="#aaaaaa">';

	// LOOP THROUGH WEEKDAY ARRAY
	for (i in astrWeekDaysAbbrev)
	{
		strWeekDays += '<td align=center width=14%><font face="verdana, arial" size=1>' + astrWeekDaysAbbrev[i] +'</font></td>';
	}
	strWeekDays += '</TR><TR>';
	strCal += strWeekDays;
   
	for (i=0; i < datFirstDayOfMonth.getDay(); i++)  
	{
		strCal += InactiveDay(datFirstDayOfMonth.getDay() - i, datCurrent);
	}
  
	for (i=1; i < intDaysInMonth+1; i++)  
	{
		datCurrent.setDate(i);
		strCal += ActiveDay(i, datCurrent);
		
		if (datCurrent.getDay() == 6) 
		{ 
			strCal +='</tr><tr>';      
    	}
	}

	datCurrent = new Date(intYear, intMonth+1, 1);
	for (i=1; i < 43-intDaysInMonth-datFirstDayOfMonth.getDay(); i++)  
	{
		datCurrent.setDate(i);
		strCal += InactiveDay(1-i, datCurrent);
		
		if (datCurrent.getDay() == 6) 
		{ 
			strCal +='</tr><tr>';      
    	}
	}
  
	return strCal;
}


function InactiveDay(intDayOffset, dDate)
{
	//' Draws a day cell - date is in previous or next month
	var datDayNum;
	var datWorkingDate = new Date(dDate.getYear(), dDate.getMonth(), (- intDayOffset) + 1) 
	var strTemp = new String(); 

	datDayNum = datWorkingDate.getDate();

	strTemp = '<td bgcolor="#eeeeee" align=center>';
	strTemp += '<font face="verdana, arial" size=2 color="darkgray">';
	strTemp += datDayNum + '</font></td>';
	return strTemp;
}


function ActiveDay(datDayNum, dDate)
{
	//' Draws a day cell - date is in current month
	var strDayDate = new String();
	var strDayFormatted = new String();
	var strTemp = new String(); 

	strDayDate = (dDate.getMonth()+1) + '/' + datDayNum + '/' + dDate.getFullYear();
	strDayFormatted = datDayNum + '/' + GetMonthName(dDate.getMonth(), true) + '/' + dDate.getFullYear();
	strTemp += '<td class="calReg" ';
	strTemp += 'onclick="javascript:parent.ctlCalcField.value=(\'' + strDayDate + '\'); parent.ctlShowField.value=(\'' + strDayFormatted + '\'); parent.HideCal();"';
	strTemp += ' align=center>';
	strTemp += '<font face="verdana, arial" size=2><a href="#" onclick="void(\'' + strDayDate + '\');">' + datDayNum + '</a>';
	strTemp +='</font></td>';
	return strTemp;
}


function HideCal()
{
	ctlFrame.style.display = "none"
}


function GetNextMonth(datCurrentDate)
{
	// IF MONTH IS DECEMBER, SET MONTH TO JANUARY AND INCREMENT THE YEAR
    if (datCurrentDate.getMonth == 11)
    {
        datCurrentDate.setMonth(0);
        datCurrentDate.setYear(datCurrentDate.getYear() + 1);
    }
    else
    {
        datCurrentDate.setMonth(datCurrentDate.getMonth() + 1);
    }
    return datCurrentDate;
}


function GetDaysInMonth(intMonth, intYear) 
{
	var dPrevDate = new Date(intYear, intMonth+1, 0);
	return dPrevDate.getDate();
}


function GetMonthName(intMonth, blnAbbrev)
{
	astrMonthName = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
	astrMonthAbbrev = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
	if (blnAbbrev == true)
		return astrMonthAbbrev[intMonth];
	else
		return astrMonthName[intMonth];
}
