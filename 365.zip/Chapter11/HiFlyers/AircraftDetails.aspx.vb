Public Class AircraftDetails
    Inherits System.Web.UI.Page
    Protected WithEvents lstAircraft As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtID As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtReg As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtManuf As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtModel As System.Web.UI.WebControls.TextBox
    Protected WithEvents chkAeros As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkIMC As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkNight As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkMulti As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents btnBookings As System.Web.UI.WebControls.Button
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents cdAllAircraft As System.Data.SqlClient.SqlCommand
    Protected WithEvents cdUpdateAircraft As System.Data.SqlClient.SqlCommand
    Protected WithEvents cdAircraftDetails As System.Data.SqlClient.SqlCommand

    Protected drDetails As SqlClient.SqlDataReader

    Protected Const AIRCRAFTID_COL As Integer = 0
    Protected Const REGISTRATION_COL As Integer = 1
    Protected Const MANUF_COL As Integer = 2
    Protected Const MODEL_COL As Integer = 3
    Protected Const CANDOAEROS_COL As Integer = 4
    Protected Const CANDOIMC_COL As Integer = 5
    Protected Const CANDONIGHT_COL As Integer = 6
    Protected Const CANDOMULTI_COL As Integer = 7

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        Me.cdAllAircraft = New System.Data.SqlClient.SqlCommand()
        Me.cdAircraftDetails = New System.Data.SqlClient.SqlCommand()
        Me.cdUpdateAircraft = New System.Data.SqlClient.SqlCommand()
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=.;initial catalog=HiFlyer;user id=sa;password=;workstation id=DAYTONA" & _
        "-NET;packet size=4096"
        '
        'cdAllAircraft
        '
        Me.cdAllAircraft.CommandText = "SELECT AircraftID, Registration FROM Aircraft"
        Me.cdAllAircraft.Connection = Me.cn
        '
        'cdAircraftDetails
        '
        Me.cdAircraftDetails.CommandText = "SELECT AircraftID, Registration, Manuf, Model, CanDoAeros, CanDoIMC, CanDoNight, " & _
        "CanDoMulti FROM Aircraft WHERE (AircraftID = @AircraftID)"
        Me.cdAircraftDetails.Connection = Me.cn
        Me.cdAircraftDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AircraftID", System.Data.SqlDbType.Int, 4, "AircraftID"))
        '
        'cdUpdateAircraft
        '
        Me.cdUpdateAircraft.CommandText = "UPDATE Aircraft SET Registration = @Registration, Manuf = @Manuf, Model = @Model," & _
        " CanDoAeros = @CanDoAeros, CanDoIMC = @CanDoIMC, CanDoNight = @CanDoNight, CanDo" & _
        "Multi = @CanDoMulti WHERE (AircraftID = @AircraftID)"
        Me.cdUpdateAircraft.Connection = Me.cn
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AircraftID", System.Data.SqlDbType.Int, 4, "AircraftID"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Registration", System.Data.SqlDbType.Variant, 7, "Registration"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Manuf", System.Data.SqlDbType.Variant, 20, "Manuf"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Model", System.Data.SqlDbType.Variant, 20, "Model"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CanDoAeros", System.Data.SqlDbType.Variant, 1, "CanDoAeros"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CanDoIMC", System.Data.SqlDbType.Variant, 1, "CanDoIMC"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CanDoNight", System.Data.SqlDbType.Variant, 1, "CanDoNight"))
        Me.cdUpdateAircraft.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CanDoMulti", System.Data.SqlDbType.Variant, 1, "CanDoMulti"))

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If IsPostBack = False Then
            Dim dr As SqlClient.SqlDataReader
            cn.Open()
            dr = cdAllAircraft.ExecuteReader
            lstAircraft.DataSource = dr
            lstAircraft.DataBind()
            dr.Close()
            cn.Close()

            lstAircraft.DataSource = Nothing
            ShowDetails(CLng(lstAircraft.SelectedItem.Value))
        End If
    End Sub

    Private Sub lstAircraft_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstAircraft.SelectedIndexChanged
        ShowDetails(CLng(lstAircraft.SelectedItem.Value))
        lblError.Visible = False
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            With cdUpdateAircraft.Parameters
                .Item("@AircraftID").Value = CInt(txtID.Text)
                .Item("@Registration").Value = txtReg.Text
                .Item("@Manuf").Value = txtManuf.Text
                .Item("@Model").Value = txtModel.Text
                .Item("@CanDoAeros").Value = CInt(chkAeros.Checked)
                .Item("@CanDoIMC").Value = CInt(chkIMC.Checked)
                .Item("@CanDoNight").Value = CInt(chkNight.Checked)
                .Item("@CanDoMulti").Value = CInt(chkMulti.Checked)
            End With

            cn.Open()
            cdUpdateAircraft.ExecuteNonQuery()

        Catch ex As Exception
            lblError.Text = "Unable to perform update for Aircraft " + txtID.Text
            lblError.Visible = True
        Finally
            cn.Close()
        End Try
    End Sub

    Private Sub ShowDetails(ByVal AircraftID As Long)
        cn.Open()
        cdAircraftDetails.Parameters(0).Value = AircraftID
        drDetails = cdAircraftDetails.ExecuteReader(CommandBehavior.SingleRow)
        drDetails.Read()
        Me.DataBind()
        cn.Close()
    End Sub

    Private Sub btnBookings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBookings.Click
        Response.Redirect("AircraftBookings.aspx?AircraftID=" + lstAircraft.SelectedItem.Value)
    End Sub

End Class
