Public Class NavigationPage2
    Inherits System.Web.UI.Page
    Protected WithEvents btnMakePayment As System.Web.UI.WebControls.Button
    Protected WithEvents btnPlaceOrder As System.Web.UI.WebControls.Button
    Protected WithEvents btnSelectProduct As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub btnSelectInstructor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlaceOrder.Click
        If IsNothing(Session("NavTicket")) Then
            Server.Transfer("Login.aspx")
        Else
            'Perform validation and ensure an instructor is selected

            Dim NavTicket As Ticket = CType(Session("NavTicket"), Ticket)
            NavTicket.HasSelectedInstructor = True
        End If
    End Sub
End Class
