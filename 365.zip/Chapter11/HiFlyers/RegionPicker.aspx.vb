Public Class RegionPicker
    Inherits System.Web.UI.Page
    Protected WithEvents SourceList As System.Web.UI.WebControls.ListBox
    Protected WithEvents SelectedList As System.Web.UI.WebControls.ListBox
    Protected WithEvents btnSelect As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Page.IsPostBack = False Then
            With SourceList
                .Items.Add("North")
                .Items.Add("West")
                .Items.Add("Central")
                .Items.Add("East")
                .Items.Add("South")
            End With
        End If
    End Sub

    Private Sub btnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click
        If SourceList.SelectedIndex >= 0 Then
            SelectedList.ClearSelection()
            SelectedList.Items.Add(SourceList.SelectedItem)
            SourceList.Items.Remove(SourceList.SelectedItem)
        End If
    End Sub
End Class
