Public Enum NavBarOrientation
    Horizontal
    Vertical
End Enum

Public MustInherit Class NavBar
    Inherits System.Web.UI.UserControl
    Protected WithEvents tblMain As System.Web.UI.WebControls.Table

    Public Event Command(ByVal CommandName As String)

    'Local vars to control the configuration of the NavBar
    Private m_intOrientation As NavBarOrientation
    Private m_blnAddedControls As Boolean

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public Property Orientation() As NavBarOrientation
        Get
            Return m_intOrientation
        End Get
        Set(ByVal Value As NavBarOrientation)
            'Cannot set orientation after adding any Links or Buttons
            If m_blnAddedControls Then
                Throw New System.Exception("Cannot set Orientation after adding Links or Buttons")
            Else
                m_intOrientation = Value
            End If
        End Set
    End Property

    Public ReadOnly Property NumControls() As Integer
        Get
            If m_intOrientation = NavBarOrientation.Horizontal Then
                Return tblMain.Rows(0).Cells.Count
            Else
                Return tblMain.Rows.Count
            End If
        End Get
    End Property

    Public Sub AddLink(ByVal Caption As String, ByVal URL As String)
        'Create a new HyperLink and a cell to contain it
        Dim lnkTemp As New HyperLink()
        Dim celTemp As TableCell = AddCell()

        'Set the props of the hyperlink
        lnkTemp.Text = Caption
        lnkTemp.NavigateUrl = URL

        'Then add to the Controls collection of the cell
        celTemp.Controls.Add(lnkTemp)
    End Sub

    Public Sub AddButton(ByVal Caption As String, ByVal URL As String)
        'Create a new Button and a cell to contain it
        Dim btnTemp As New Button()
        Dim celTemp As TableCell = AddCell()

        'Set the Caption and the CommandName
        btnTemp.Text = Caption
        btnTemp.CommandName = URL

        'Associate with an event handler
        AddHandler btnTemp.Command, AddressOf ButtonClicked

        'Add to the Controls collection of the cell
        celTemp.Controls.Add(btnTemp)
    End Sub

    Private Function AddCell() As TableCell
        'Purpose: Add a new cell in the table, allowing
        'for the orientation to be vert or horizontal
        Dim celTemp As New TableCell()
        Dim rowTemp As TableRow

        If m_intOrientation = NavBarOrientation.Horizontal Then
            'Single row needed, so just use the current one
            rowTemp = tblMain.Rows(0)
        ElseIf m_blnAddedControls = False Then
            'Multi rows needed, but this is the first so just use the current one
            rowTemp = tblMain.Rows(0)
        Else
            'Multiple rows needed, and we need to add one
            rowTemp = New TableRow()
            tblMain.Rows.Add(rowTemp)
        End If

        'Add the new cell to the chosen row
        rowTemp.Cells.Add(celTemp)

        'Indicate that we've added a control
        m_blnAddedControls = True

        Return celTemp
    End Function

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Set the default for the flag
        m_blnAddedControls = False
    End Sub

    Private Sub ButtonClicked(ByVal sender As System.Object, ByVal e As System.web.UI.webcontrols.CommandEventArgs)
        'Triggered when a NavBar button is clicked
        'URL was defined in the CommandName
        RaiseEvent Command(e.CommandName)
        'Response.Redirect(e.CommandName)
    End Sub
End Class
