Public Class NavigationPage31
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If IsNothing(Session("NavTicket")) Then
            Server.Transfer("Login.aspx")
        Else
            Dim NavTicket As Ticket = CType(Session("NavTicket"), Ticket)

            If Not NavTicket.HasLoggedIn Then
                Server.Transfer("Login.aspx")
            ElseIf Not NavTicket.HasSelectedAircraft Then
                Server.Transfer("SelectAircraft.aspx")
            ElseIf Not NavTicket.HasSelectedInstructor Then
                Server.Transfer("SelectInstructor.aspx")
            ElseIf Not NavTicket.HasSelectedDate Then
                Server.Transfer("SelectDate.aspx")
            End If
        End If
    End Sub

End Class
