Public Class AircraftBookings
    Inherits System.Web.UI.Page
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents daAircraftBookings As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents grdBookings As System.Web.UI.WebControls.DataGrid
    
    Protected AircraftID As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.daAircraftBookings = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        '
        'daAircraftBookings
        '
        Me.daAircraftBookings.SelectCommand = Me.SqlSelectCommand1
        Me.daAircraftBookings.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "AircraftDiary", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("AircraftDiaryID", "AircraftDiaryID"), New System.Data.Common.DataColumnMapping("DiaryDate", "DiaryDate"), New System.Data.Common.DataColumnMapping("Status", "Status"), New System.Data.Common.DataColumnMapping("MemberName", "MemberName")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT AircraftDiary.AircraftDiaryID, AircraftDiary.DiaryDate, AircraftDiary.Stat" & _
        "us, Member.Title + ' ' + Member.Forename + ' ' + Member.Surname AS MemberName FR" & _
        "OM AircraftDiary INNER JOIN Member ON AircraftDiary.BookedMemberID = Member.Memb" & _
        "erID WHERE (AircraftDiary.AircraftID = @AircraftID)"
        Me.SqlSelectCommand1.Connection = Me.cn
        Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AircraftID", System.Data.SqlDbType.Int, 4, "AircraftID"))
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=.;initial catalog=HiFlyer;password="""";persist security info=True;user" & _
        " id=sa;workstation id=DAYTONA-NET;packet size=4096"

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If IsPostBack = False Then
            AircraftID = CInt(Request("AircraftID"))
            ViewState("AircraftID") = AircraftID

            ShowBookings()
        Else
            AircraftID = CInt(ViewState("AircraftID"))
        End If
    End Sub

    Private Sub ShowBookings()
        Dim ds As New DataSet()

        daAircraftBookings.SelectCommand.Parameters("@AircraftID").Value = AircraftID
        daAircraftBookings.Fill(ds, "Bookings")

        Dim dv As New DataView(ds.Tables("Bookings"))
        Try
            dv.Sort = ViewState("SortOrder").ToString
        Catch e As Exception
            'Do nothing - just leave it in the original order
        Finally
            grdBookings.DataSource = dv
            Me.DataBind()
        End Try
    End Sub

    Private Sub grdBookings_SortCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs)
        grdBookings.EditItemIndex = -1
        ViewState("SortOrder") = e.SortExpression
        ShowBookings()
    End Sub

    Private Sub grdBookings_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs)
        grdBookings.EditItemIndex = -1
        grdBookings.CurrentPageIndex = e.NewPageIndex
        ShowBookings()
    End Sub

    Private Sub grdBookings_EditCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        grdBookings.EditItemIndex = e.Item.ItemIndex
        ShowBookings()
    End Sub

    Private Sub grdBookings_CancelCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        grdBookings.EditItemIndex = -1
        ShowBookings()
    End Sub

    Private Sub grdBookings_UpdateCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        Dim strACDiaryID As String = e.Item.Cells(0).Text
        Dim strDate As String = CType(e.Item.Cells(1).Controls(0), TextBox).Text
        Dim strStatus As String = CType(e.Item.Cells(2).Controls(1), DropDownList).SelectedItem.Value

        'Try
        '    With cdUpdateBooking.Parameters
        '        .Item("@AircraftDiaryID").Value = CInt(strACDiaryID)
        '        .Item("@DiaryDate").Value = CDate(strDate)
        '        .Item("@Status").Value = strStatus
        '    End With

        '    cn.Open()
        '    cdUpdateAircraft.ExecuteNonQuery()

        '    grdBookings.EditItemIndex = -1
        '    ShowBookings()
        'Catch ex As Exception
        '    lblError.Text = "Unable to update the booking."
        '    lblError.Visible = True
        'Finally
        '    cn.Close()
        'End Try
    End Sub

    Private Sub grdBookings_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        If e.CommandName = "Details" Then
            Response.Redirect("BookingDetails.aspx?AircraftDiaryID=" + e.Item.Cells(0).Text)
        End If
    End Sub

End Class
