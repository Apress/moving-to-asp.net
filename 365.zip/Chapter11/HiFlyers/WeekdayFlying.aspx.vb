Public Class WeekdayFlying
    Inherits System.Web.UI.Page

    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents CustomValidator1 As System.Web.UI.WebControls.CustomValidator
    Protected WithEvents txtDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents ListBox1 As System.Web.UI.WebControls.ListBox
    Protected WithEvents cmdOK As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Trace.Warn("Page_Load")
    End Sub

    Private Sub CustomValidator1_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        Trace.Warn("CustomValidator1_ServerValidate")
        If IsDate(args.Value) = False Then
            args.IsValid = False
        ElseIf Weekday(Date.Parse(args.Value)) = 1 Or Weekday(Date.Parse(args.Value)) = 7 Then
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Trace.Warn("cmdOK_Click")
        If Page.IsValid Then
            'Go ahead and make the booking
        Else
            'Nope - invalid details
        End If
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        Trace.Warn("Page_PreRender")
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Trace.Warn("Page_Unload")

    End Sub

    Private Sub Page_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        Trace.Warn("Page_Disposed")

    End Sub

    Private Sub Label1_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.Init
        Trace.Warn("Label1_Init")

    End Sub

    Private Sub Label1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.Load
        Trace.Warn("Label1_Load")

    End Sub

    Private Sub Label1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.PreRender
        Trace.Warn("Label1_PreRender")

    End Sub

    Private Sub Label1_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.Unload
        Trace.Warn("Label1_Unload")

    End Sub

    Private Sub Label1_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.Disposed
        Trace.Warn("Label1_Disposed")

    End Sub

    Private Sub Label2_Init(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Trace.Warn("Label2_Init")

    End Sub

    Private Sub Label2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Trace.Warn("Label2_Load")

    End Sub

    Private Sub Label2_PreRender(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Trace.Warn("Label2_PreRender")

    End Sub

    Private Sub Label2_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Trace.Warn("Label2_Unload")

    End Sub

    Private Sub Label2_Disposed(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Trace.Warn("Label2_Disposed")

    End Sub

    Private Sub txtDate_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Init
        Trace.Warn("txtDate_Init")

    End Sub

    Private Sub txtDate_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Load
        Trace.Warn("txtDate_Load")

    End Sub

    Private Sub txtDate_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.PreRender
        Trace.Warn("txtDate_PreRender")

    End Sub

    Private Sub txtDate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.TextChanged
        Trace.Warn("txtDate_TextChanged")

    End Sub

    Private Sub txtDate_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Unload
        Trace.Warn("txtDate_Unload")

    End Sub

    Private Sub txtDate_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Disposed
        Trace.Warn("txtDate_Disposed")

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Trace.Warn("ListBox1_SelectedIndexChanged")

    End Sub

    Private Sub cmdOK_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles cmdOK.Command
        Trace.Warn("cmdOK_Command")

    End Sub
End Class
