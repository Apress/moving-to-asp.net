Public Class NavigationPage1
    Inherits System.Web.UI.Page
    Protected WithEvents btnPage1 As System.Web.UI.WebControls.Button
    Protected WithEvents btnPage2 As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim NavTicket As New Ticket()
        Session("NavTicket") = NavTicket
    End Sub

    Private Sub btnPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPage1.Click
        Response.Redirect("NavigationPage1.aspx")
    End Sub

    Private Sub btnPage2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPage2.Click
        Server.Transfer("NavigationPage2.aspx")
    End Sub
End Class
