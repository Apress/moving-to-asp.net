Public Class NavBarTest
    Inherits System.Web.UI.Page

    Protected NavBar1 As NavBar
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With NavBar1
            .Orientation = NavBarOrientation.Vertical
            .AddButton("Page1", "Page1.aspx")
            .AddButton("Page2", "Page2.aspx")
            .AddButton("Page3", "Page3.aspx")
            .AddButton("Page4", "Page4.aspx")
        End With
    End Sub
End Class
