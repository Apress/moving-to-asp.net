Public Class FlightSummaryByAircraft
    Inherits System.Web.UI.Page
    Protected WithEvents cn As System.Data.SqlClient.SqlConnection
    Protected WithEvents cdFlightSummary As System.Data.SqlClient.SqlCommand
    Protected WithEvents Datalist2 As System.Web.UI.WebControls.DataList
    Protected WithEvents DataList1 As System.Web.UI.WebControls.DataList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cdFlightSummary = New System.Data.SqlClient.SqlCommand()
        Me.cn = New System.Data.SqlClient.SqlConnection()
        '
        'cdFlightSummary
        '
        Me.cdFlightSummary.CommandText = "SELECT Aircraft.Registration, Aircraft.Manuf, Aircraft.Model, COUNT(AircraftDiary" & _
        ".AircraftDiaryID) AS Flights, CASE WHEN COUNT(AircraftDiary.AircraftDiaryID) < 5" & _
        " THEN 'RED' WHEN COUNT(AircraftDiary.AircraftDiaryID) < 15 THEN 'BLUE' ELSE 'GRE" & _
        "EN' END AS AlertColor FROM Aircraft LEFT OUTER JOIN AircraftDiary ON Aircraft.Ai" & _
        "rcraftID = AircraftDiary.AircraftID WHERE (AircraftDiary.DiaryDate BETWEEN @Star" & _
        "tDate AND @EndDate) GROUP BY Aircraft.Registration, Aircraft.Manuf, Aircraft.Mod" & _
        "el"
        Me.cdFlightSummary.Connection = Me.cn
        Me.cdFlightSummary.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StartDate", System.Data.SqlDbType.DateTime, 8, "DiaryDate"))
        Me.cdFlightSummary.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EndDate", System.Data.SqlDbType.DateTime, 8, "DiaryDate"))
        '
        'cn
        '
        Me.cn.ConnectionString = "data source=.;initial catalog=HiFlyer;password="""";persist security info=True;user" & _
        " id=sa;workstation id=DAYTONA-NET;packet size=4096"

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected dr As SqlClient.SqlDataReader

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Me.IsPostBack = False Then

            cn.Open()
            cdFlightSummary.Parameters("@StartDate").Value = #1/1/2002#
            cdFlightSummary.Parameters("@EndDate").Value = #12/31/2002#
            dr = cdFlightSummary.ExecuteReader()

            Datalist2.DataSource = dr
            Datalist2.DataBind()

            dr.Close()
            cn.Close()
        End If
    End Sub

    Private Sub DataList1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataList1.SelectedIndexChanged

    End Sub
End Class
