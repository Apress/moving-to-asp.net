Imports System.Text.RegularExpressions

Public Class MobileWebForm1
    Inherits System.Web.UI.MobileControls.MobilePage
    Protected WithEvents frmAvail As System.Web.UI.MobileControls.Form
    Protected WithEvents frmNews As System.Web.UI.MobileControls.Form
    Protected WithEvents frmWeather As System.Web.UI.MobileControls.Form
    Protected WithEvents lblHeading As System.Web.UI.MobileControls.Label
    Protected WithEvents lnkWeather As System.Web.UI.MobileControls.Link
    Protected WithEvents lnkNews As System.Web.UI.MobileControls.Link
    Protected WithEvents lnkAvail As System.Web.UI.MobileControls.Link
    Protected WithEvents txtICAOCode As System.Web.UI.MobileControls.TextBox
    Protected WithEvents lblWeather As System.Web.UI.MobileControls.Label
    Protected WithEvents lnkBack1 As System.Web.UI.MobileControls.Link
    Protected WithEvents btnCheckWeather As System.Web.UI.MobileControls.Command
    Protected WithEvents lblEnterCode As System.Web.UI.MobileControls.Label
    Protected WithEvents lblHeading1 As System.Web.UI.MobileControls.Label
    Protected WithEvents valCodeExpression As System.Web.UI.MobileControls.RegularExpressionValidator
    Protected WithEvents valCodeRequired As System.Web.UI.MobileControls.RequiredFieldValidator
    Protected WithEvents valCodeRecognized As System.Web.UI.MobileControls.CustomValidator
    Protected WithEvents frmICAOError As System.Web.UI.MobileControls.Form
    Protected WithEvents Label1 As System.Web.UI.MobileControls.Label
    Protected WithEvents valICAOCodeErrors As System.Web.UI.MobileControls.ValidationSummary
    Protected WithEvents lnkBack2 As System.Web.UI.MobileControls.Link
    Protected WithEvents lnkBack3 As System.Web.UI.MobileControls.Link
    Protected WithEvents objlstNews As System.Web.UI.MobileControls.ObjectList
    Protected WithEvents lblHeading2 As System.Web.UI.MobileControls.Label
    Protected WithEvents lblHeading3 As System.Web.UI.MobileControls.Label
    Protected WithEvents lstAvail As System.Web.UI.MobileControls.List
    Protected WithEvents calBookIt As System.Web.UI.MobileControls.PhoneCall
    Protected WithEvents StyleSheet1 As System.Web.UI.MobileControls.StyleSheet
    Protected WithEvents frmMain As System.Web.UI.MobileControls.Form

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Page.IsPostBack = False Then
            Dim cn As New SqlClient.SqlConnection("Data Source=(local);Initial Catalog=HiFlyer;Integrated Security=SSPI;")
            Dim cdNews As New SqlClient.SqlCommand("SELECT NewsTitle, NewsDetails FROM News WHERE NewsDate='" + DateTime.Today.ToShortDateString + "'", cn)
            Dim cdAvail As New SqlClient.SqlCommand("SELECT Registration FROM Aircraft WHERE AircraftID NOT IN (SELECT AircraftID FROM AircraftDiary WHERE DiaryDate='" + DateTime.Today.ToShortDateString + "')", cn)
            Dim dr As SqlClient.SqlDataReader
            Dim fld1 As New MobileControls.ObjectListField()
            Dim fld2 As New MobileControls.ObjectListField()

            fld1.DataField = "NewsTitle"
            fld2.DataField = "NewsDetails"
            With objlstNews
                .Fields.Add(fld1)
                .Fields.Add(fld2)
            End With

            cn.Open()

            dr = cdNews.ExecuteReader
            objlstNews.DataSource = dr
            objlstNews.DataBind()
            dr.Close()

            dr = cdAvail.ExecuteReader
            lstAvail.DataSource = dr
            lstAvail.DataBind()
            dr.Close()

            cn.Close()

            Select Case Request.QueryString("FormName")
                Case "frmMain"
                    ActiveForm = frmMain
                Case "frmWeather"
                    ActiveForm = frmWeather
                Case "frmNews"
                    ActiveForm = frmNews
                Case "frmAvail"
                    ActiveForm = frmAvail
            End Select
        End If
    End Sub

    Private Sub btnCheckWeather_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckWeather.Click
        If Page.IsValid Then
            lblWeather.Text = GetWeather(txtICAOCode.Text)
        Else
            lblWeather.Text = ""
            Me.ActiveForm = frmICAOError    'Display the summary
        End If
    End Sub

    Private Sub valCodeRecognized_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles valCodeRecognized.ServerValidate
        If CheckICAOCode(txtICAOCode.Text) Then
            args.IsValid = True
        Else
            args.IsValid = False
        End If
    End Sub

    Private Function GetWeather(ByVal ICAOCode As String) As String
        Dim rnd As New Random()
        Select Case CInt(rnd.Next(3))
            Case 0
                Return "Sky is Clear"
            Case 1
                Return "It is Raining"
            Case 2
                Return "It is Stormy"
            Case Else
                Return "Unavailable"
        End Select
    End Function

    Private Function CheckICAOCode(ByVal ICAOCode As String) As Boolean
        Dim reg As Regex
        Dim m As Match

        reg = New Regex("[ek][a-z]{3}", RegexOptions.IgnoreCase)

        m = reg.Match(ICAOCode)
        If m.Success Then
            Return True
        Else
            Return False
        End If
    End Function
End Class
