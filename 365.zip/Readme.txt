This zip file contains the source code listings and projects to accompany 
"Moving to ASP.NET: Web Development with VB .NET" (Apress, ISBN: 1-59059-009-0).  
These extracts and samples are provided purely to illustrate the teaching points 
made in the book, and are provided "as is" and are not warranted as being fit 
for any particular purpose.  The source code may be incomplete, and may not 
function on your computer system without modification.

We have split the source code into separate chapters to make it easier for you 
to locate the examples and listings you are interested in.  Listings have been 
identified by their listing number or page number, or where an example is built 
over multiple pages it has been provided in its final form.  In addition, many 
chapters have complete projects to accompany them and these have been provided 
in subdirectories within each chapter.

To utilise any of the data access features you will first need to create and 
populate the database, and instructions for these tasks are provided in the 
SQLReadMe.txt file in the Chapter00 directory.  We strongly suggest that you 
read and follow these instructions.

best wishes and good luck

Steve and Rob
