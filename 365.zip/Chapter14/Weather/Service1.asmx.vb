Imports System.Web.Services
Imports System.Web.Services.Protocols

<WebService(Namespace:="http://apress.com/hiflyers/", _
Description:=Service1.ServiceDescription, _
Name:="AirfieldWeather")> _
Public Class Service1
    Inherits System.Web.Services.WebService

    Public Const ServiceDescription As String = _
      "A <b> Weather</b> reporting Web Service. " + _
      "Click here for <a href=""details.htm"">more</a>"
    'Public Check As ClientID

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region


    'return a ramdom temperature
    <WebMethod()> _
    Public Function Temperature() As Integer

        Temperature = (New Random()).Next(-10, 30)
    End Function


    <WebMethod()> Public Function TempForC(ByVal Fahrenheit As Boolean) As Integer
        Dim temp As Integer = (New Random()).Next(-10, 30)
        If Fahrenheit Then temp = (temp * 1.8) + 32
        Return temp
    End Function


    'return a random outlook
    <WebMethod()> Public Function Outlook() As String
        'Check.Authorize()
        Dim values() As String = {"Sun", "Cloud", "Snow", "Rain"}
        Dim random = (New Random()).Next(0, 4)
        Outlook = values(random)
    End Function

    <WebMethod()> Public Function GetAllInfo() As WeatherInfo
        Dim info As New WeatherInfo()
        Dim outlookValues() As String = {"Sun", "Cloud", "Snow", "Rain"}
        Dim directionValues() As String = {"N", "E", "S", "W", "NE", "EE", "SW", "NW"}
        Dim random As Integer
        info.Temperature = (New Random()).Next(-10, 30)
        random = (New Random()).Next(0, 4)
        info.Outlook = outlookValues(random)
        info.WindSpeed = (New Random()).Next(80)
        random = (New Random()).Next(0, 8)
        info.WindDirection = directionValues(random)
        Return info
    End Function

    <WebMethod()> Public Sub GetWeather( _
    ByRef Temperature As Integer, _
    ByRef Outlook As String, _
    ByRef WindSpeed As Double, _
    ByRef WindDirection As String)
        Dim info As New WeatherInfo()
        Dim outlookValues() As String = {"Sun", "Cloud", "Snow", "Rain"}
        Dim directionValues() As String = {"N", "E", "S", "W", "NE", "EE", "SW", "NW"}
        Dim random As Integer
        Temperature = (New Random()).Next(-10, 30)
        random = (New Random()).Next(0, 4)
        Outlook = outlookValues(random)
        WindSpeed = (New Random()).Next(80)
        random = (New Random()).Next(0, 8)
        WindDirection = directionValues(random)
        Dim ds As DataSet
        Context.Cache("Data") = ds
    End Sub

End Class

Public Class WeatherInfo
    Public Temperature As Integer
    Public Outlook As String
    Public WindSpeed As Double
    Public WindDirection As String
End Class

Public Class ClientID
    Inherits SoapHeader

    Public Username As String
    Public Password As String

    Public Sub Authorize()
        If Username <> "GoodGuy" And Password <> "secret" Then
            ' throw an error unless user is authorised            
            Throw New SoapHeaderException _
                ("Invalid User", SoapException.ClientFaultCode)
        End If
    End Sub
End Class

