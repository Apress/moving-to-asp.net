Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnWeather As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblTemp As System.Windows.Forms.Label
    Friend WithEvents lblOutlook As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents pcbOutlook As System.Windows.Forms.PictureBox
    Friend WithEvents lblWindDirection As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblWindSpeed As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnWeather = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTemp = New System.Windows.Forms.Label()
        Me.lblOutlook = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pcbOutlook = New System.Windows.Forms.PictureBox()
        Me.lblWindDirection = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblWindSpeed = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnWeather
        '
        Me.btnWeather.Location = New System.Drawing.Point(16, 16)
        Me.btnWeather.Name = "btnWeather"
        Me.btnWeather.Size = New System.Drawing.Size(232, 40)
        Me.btnWeather.TabIndex = 0
        Me.btnWeather.Text = "Get Weather"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Temperature"
        '
        'lblTemp
        '
        Me.lblTemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTemp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTemp.Location = New System.Drawing.Point(160, 72)
        Me.lblTemp.Name = "lblTemp"
        Me.lblTemp.Size = New System.Drawing.Size(62, 24)
        Me.lblTemp.TabIndex = 2
        '
        'lblOutlook
        '
        Me.lblOutlook.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutlook.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutlook.Location = New System.Drawing.Point(160, 112)
        Me.lblOutlook.Name = "lblOutlook"
        Me.lblOutlook.Size = New System.Drawing.Size(62, 24)
        Me.lblOutlook.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 24)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Outlook"
        '
        'pcbOutlook
        '
        Me.pcbOutlook.Location = New System.Drawing.Point(64, 152)
        Me.pcbOutlook.Name = "pcbOutlook"
        Me.pcbOutlook.Size = New System.Drawing.Size(144, 104)
        Me.pcbOutlook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pcbOutlook.TabIndex = 5
        Me.pcbOutlook.TabStop = False
        '
        'lblWindDirection
        '
        Me.lblWindDirection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWindDirection.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWindDirection.Location = New System.Drawing.Point(168, 312)
        Me.lblWindDirection.Name = "lblWindDirection"
        Me.lblWindDirection.Size = New System.Drawing.Size(62, 24)
        Me.lblWindDirection.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(24, 312)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(128, 24)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Wind Direction"
        '
        'lblWindSpeed
        '
        Me.lblWindSpeed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWindSpeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWindSpeed.Location = New System.Drawing.Point(168, 272)
        Me.lblWindSpeed.Name = "lblWindSpeed"
        Me.lblWindSpeed.Size = New System.Drawing.Size(62, 24)
        Me.lblWindSpeed.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(24, 272)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 24)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Wind Speed"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(264, 349)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblWindDirection, Me.Label4, Me.lblWindSpeed, Me.Label6, Me.pcbOutlook, Me.lblOutlook, Me.Label3, Me.lblTemp, Me.Label1, Me.btnWeather})
        Me.Name = "Form1"
        Me.Text = "Weather Report"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnWeather_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWeather.Click

        Dim img As Bitmap

        Dim pxy As New localhost.AirfieldWeather()
        Dim info As localhost.WeatherInfo
        pxy.Credentials = System.Net.CredentialCache.DefaultCredentials
        pxy.ClientIDValue = New localhost.ClientID()
        pxy.ClientIDValue.Username = "GoodGuy"
        pxy.ClientIDValue.Password = "secret"
        
        info = pxy.GetAllInfo
        
        lblTemp.Text = info.Temperature.ToString
        lblOutlook.Text = info.Outlook
        lblWindSpeed.Text = info.WindSpeed.ToString
        lblWindDirection.Text = info.WindDirection

        img = New Bitmap("..\" + info.Outlook + ".ico")
        pcbOutlook.Image = CType(img, Image)

        lblTemp.Text = pxy.Temperature.ToString
        lblOutlook.Text = pxy.Outlook
    End Sub
End Class

'pxy.Credentials = New _
'            System.Net.NetworkCredential _
'            ("Administrator", "Weasel100")
